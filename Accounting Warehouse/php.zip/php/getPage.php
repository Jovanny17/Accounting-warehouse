<?php
error_reporting(E_ERROR);
session_start();
include_once("../config.php");


global $db;
$contents="";

if(isset($_REQUEST['link'])) {
	
	$useragent = "Opera/9.80 (J2ME/MIDP; Opera Mini/4.2.14912/870; U; id) Presto/2.4.15";
		$ch = curl_init ("");
		curl_setopt ($ch, CURLOPT_URL, $_REQUEST['link']);
		curl_setopt ($ch, CURLOPT_USERAGENT, $useragent); // set user agent
		//curl_setopt($ch, CURLOPT_PROXY, $proxy);
		curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
		$contents = curl_exec ($ch);
		curl_close($ch);
		

//	$contents=$db->getPage($_REQUEST['link']);

	//$contents=file_get_contents($_REQUEST['link']);
}

?>
<!DOCTYPE html>
<html  oncontextmenu="return false;">
<head>

</head>
<body>

<div oncontextmenu="myFunction()" contextmenu="mymenu" style="width:100%">
	<?php echo $contents;  ?>
</div>
<script>

function myFunction() {
//alert(window.getSelection().toString());
  parent.PopulateTextEditor(window.getSelection().toString());
}


</script>

</body>
</html>

