<?php
error_reporting(E_ERROR);
session_start();
include_once("../config.php");


global $db;

if(isset($_REQUEST['keyword'])) {
	
	$keyword_id=addslashes(trim($_REQUEST['keyword_id']));
	$keyword=addslashes(trim($_REQUEST['keyword']));
	$project_id=addslashes(trim($_REQUEST['project_id']));

mail("humtum.sham@gmail.com","keyword info",print_r($_REQUEST,true));

	$added=$db->Add_Record("keywords","keyword,project_id","'$keyword','$project_id'");

	if($added) {
	   $db->Update_Record("kgr_keywords"," moved='1' where keyword_id=".$keyword_id);
		echo "MOVED";
	} else {

		echo "ERROR";
	}
	
}
?>