<?php
error_reporting(E_ERROR);
session_start();
include_once("../config.php");


global $db;

if(isset($_POST['link_id'])) {
	
	$link_id=addslashes(trim($_POST['link_id']));
	$web_link=addslashes(trim($_POST['web_link']));

	$updated=$db->Update_Record("backlinks","result_link='$web_link',completed_by='$_SESSION[user_id]',status='1' where link_id=$link_id");

	if($updated) {
		echo "1";
	} else {

		echo "0";
	}
	
}
?>