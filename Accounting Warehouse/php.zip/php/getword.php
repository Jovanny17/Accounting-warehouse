<?php
include_once("../config.php");
global $db;

$word=addslashes(trim($_REQUEST['word']));

$query="select * from words where word='".$word."'";
$found=$db->countRecords($query);

if($found <=0) {
	$contents=file_get_contents("https://relatedwords.org/api/related?term=".$word);
	$db->Add_Record("words","word,related","'".$word."','".addslashes($contents)."'");
} else {
	$word_info=$db->selectFrom($query);
	$contents=$word_info['related'];

}

$content=json_decode(stripslashes($contents));

?>
<?php for($i=0;$i<10;$i++) { ?>
<a href="#" onclick="HideMenu();" style="position:absolute; right:10px; top:10px">X</a>
<div class="context_item"> 
    <div class="inner_item" onclick="ReplaceWord('<?php echo $content[$i]->word; ?>');"><?php echo $content[$i]->word; ?></div> 
  </div>
 <?php } ?>