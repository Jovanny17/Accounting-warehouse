  <?php
session_start();
include("../config.php");
                    
$ToDate=isset($_POST['ToDate'])?$_POST['ToDate']:'01/01/2001';
$FromDate=isset($_POST['FromDate'])?$_POST['FromDate']:'01/01/2021';
$filter=isset($_POST['filter'])?$_POST['filter']:'0';
if($filter=="1")
{


 $AccType=$db->selectMultiRecords("SELECT m.ID,m.JournalDate
        ,w.WorkFlow,ws.WorkFlowState,m.description FROM journalmaster m join tblworkflow w
on
m.WorkFlowTypeID=w.ID join
tblworkflowstate ws on m.WorkFlowStateID=ws.ID


m.JournalDate between '$FromDate' and '$ToDate'

order by m.ID desc ");

?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"> 
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>

<?php


                   


$Debit=0;
$Credit=0;
 if($_SESSION["group_id"]=="1" )
                    {
foreach($AccType as $Type)
{
                              $id=$Type['ID'];
                          $Debit=0;
$Credit=0;

$AccTpe=$Type['Invocie'];
                                      
   $accounts=$db->selectMultiRecords("select  j.AccType,j.accounts, j.debit, j.credit from journal j where j.JMID='".$id."' group by j.accounts order by j.accType");
                        foreach($accounts as $account){
                        $Debit += $account['debit'];
                        $Credit += $account['credit'];                 
                         echo '<tr>
                               <th>'.$Type['ID'].'</th>
                                <th>'.$Type['JournalDate'].'</th>
                               <td>'.$account["accounts"].'</td>
                               
                                 <th>'.$Type["description"].'</th>
                                 <td style="text-align:right;>$<span class="font-weight-bold">$'.number_format($Debit,2).'</span></td>
                                <td style="text-align:right;>$<span class="font-weight-bold">$'. number_format($Credit,2).'</span></td>
                                <td style="text-align:right;>$<span class="font-weight-bold">$'. number_format($Credit - $Debit,2).'</span></td>
                                 <td style="text-align:right;>$<span class="font-weight-bold"><a href="journal.php">'. $PR.'</span></a></td>
                                 
                             </tr>
                             
                             

                             ';
                        

                         

                       /* foreach($accounts as $account){
$Debit += $account['debit'];
$Credit += $account['credit'];
                   
                         echo  '<tr class="warning">
                                <td>'.$account["accounts"].'</td>
                                <td style="width:50px">'.$account["AccType"].'</td>
                                
                                <td style="text-align:right;width:100px;">$<span class="debit">'.number_format($account['debit'],2).'</span></td>
                                <td style="text-align:right; width:100px;">$<span class="credit">'.number_format($account['credit'],2).'</span></td>
                              

                                 </tr>';*/
                          
                  
             

                      //  }
                       

                        }

                        
 echo '<tr class="primary">
                                <td colspan="4">Total</td>
                             
                                <td style="text-align:right;>$<span class="font-weight-bold">$'.number_format($Debit,2).'</span></td>
                             
                                
                                
                                <td style="text-align:right;>$<span class="font-weight-bold">$'. number_format($Credit,2).'</span></td>
                             
                                 
                              
                                
                             </tr>';
                         }

                          
                    }// Session 1 close
                    else
                    {
                        foreach($AccType as $Type)



                        {
                              $id=$Type['ID'];
                          $Debit=0;
$Credit=0;

$AccTpe=$Type['Invocie'];
                                      
                    
  echo '<tr class="dark odd">
     <th>'.$Type['JournalDate'].'</th>
                                <th>'.$AccTpe.'</th>
                                
                                
                                 <td>'.$Type["WorkFlowState"].'</td>
                                 <td colspan="3">'.$Type["description"].'</td>
           
                   <td colspan="2">
                    <a href="add_journal.php?JMID='.$id.'&IsEdit=edit" id="$id"  class="btn  btn-warning edit" ><i class="fa fa-pencil"></i></a>
                    </td>
                   
                             </tr>';

                         
$accounts=$db->selectMultiRecords("select  j.AccType,j.accounts, j.debit, j.credit from journal j where j.JMID='".$id."' group by j.accounts order by j.accType");
                        foreach($accounts as $account){
$Debit += $account['debit'];
$Credit += $Tyaccountpe['credit'];
                   
                           echo '<tr class="warning">
                                <td colspan="3">'.$account["accounts"].'</td>
                                <td >'.$account["AccType"].'</td>
                             
                                <td>$<span class="debit">'.$account["debit"].'</span></td>
                             
                                
                                
                                <td>$<span class="credit">'.$account["credit"].'</span></td>
                             
                                 
                              
                                
                             </tr>';
                          
                  
             

                      //  }
                       

                       

                        }
                           echo '<tr class="primary">
                                <td colspan="4">Total</td>
                             
                                <td>$<span class="font-weight-bold">'.$Debit.'</span></td>
                             
                                
                                
                                <td>$<span class="font-weight-bold">'. $Credit.'</span></td>
                             
                                 
                              
                                
                             </tr>';
                         }
                    }

                    
}
else
{
      
 $AccType=$db->selectMultiRecords("SELECT m.ID,m.JournalDate
        ,w.WorkFlow,ws.WorkFlowState,m.description FROM journalmaster m join tblworkflow w
on
m.WorkFlowTypeID=w.ID join
tblworkflowstate ws on m.WorkFlowStateID=ws.ID



order by m.ID desc ");


                   


$Debit=0;
$Credit=0;
$PR="J-". rand(5, 15);
 if($_SESSION["group_id"]=="2" || $_SESSION["group_id"]=="1")
                    {

foreach($AccType as $Type)
{
                              $id=$Type['ID'];
                          $Debit=0;
$Credit=0;

$AccTpe=$Type['Invocie'];
                                      
   $accounts=$db->selectMultiRecords("select  j.AccType,j.accounts, j.debit, j.credit from journal j where j.JMID='".$id."' group by j.accounts order by j.accType");
                        foreach($accounts as $account){
                        $Debit += $account['debit'];
                        $Credit += $account['credit'];                 
                         echo '<tr>
                               <th>'.$Type['ID'].'</th>
                                <th>'.$Type['JournalDate'].'</th>
                               <td>'.$account["accounts"].'</td>
                               
                                 <th>'.$Type["description"].'</th>
                                 <td style="text-align:right;>$<span class="font-weight-bold">$'.number_format($Debit,2).'</span></td>
                                <td style="text-align:right;>$<span class="font-weight-bold">$'. number_format($Credit,2).'</span></td>
                                <td style="text-align:right;>$<span class="font-weight-bold">$'. number_format($Credit - $Debit,2).'</span></td>
                                 <td style="text-align:right;>$<span class="font-weight-bold"><a href="journal.php">'. $PR.'</span></a></td>
                                 
                             </tr>
                             
                             

                             ';
                        

                         

                       /* foreach($accounts as $account){
$Debit += $account['debit'];
$Credit += $account['credit'];
                   
                         echo  '<tr class="warning">
                                <td>'.$account["accounts"].'</td>
                                <td style="width:50px">'.$account["AccType"].'</td>
                                
                                <td style="text-align:right;width:100px;">$<span class="debit">'.number_format($account['debit'],2).'</span></td>
                                <td style="text-align:right; width:100px;">$<span class="credit">'.number_format($account['credit'],2).'</span></td>
                              

                                 </tr>';*/
                          
                  
             

                      //  }
                       

                        }

                        
 echo '<tr class="primary">
                                <td colspan="4">Total</td>
                             
                                <td style="text-align:right;>$<span class="font-weight-bold">$'.number_format($Debit,2).'</span></td>
                             
                                
                                
                                <td style="text-align:right;>$<span class="font-weight-bold">$'. number_format($Credit,2).'</span></td>
                             
                                 
                              
                                
                             </tr>';
                         }
}
                          

                    else
                    {
                        foreach($AccType as $Type)



                        {
                              $id=$Type['ID'];
                          $Debit=0;
$Credit=0;

$AccTpe=$Type['Invocie'];
                                      
                    
  echo '<tr class="dark odd">
     <th>'.$Type['JournalDate'].'</th>
                                <th>'.$AccTpe.'</th>
                                
                                
                                 <td>'.$Type["WorkFlowState"].'</td>
                                 <td colspan="3">'.$Type["description"].'</td>
           
                   <td colspan="2">
                    <a href="add_journal.php?JMID='.$id.'&IsEdit=edit" id="$id"  class="btn  btn-warning edit" ><i class="fa fa-pencil"></i></a>
                    </td>
                   
                             </tr>';

                         
$accounts=$db->selectMultiRecords("select  j.AccType,j.accounts, j.debit, j.credit from journal j where j.JMID='".$id."' group by j.accounts order by j.accType");
                        foreach($accounts as $account){
$Debit += $account['debit'];
$Credit += $account['credit'];
                   
                           echo '<tr class="warning">
                                <td colspan="3">'.$account["accounts"].'</td>
                                <td >'.$account["AccType"].'</td>
                             
                                <td>$<span class="debit">'.$account["debit"].'</span></td>
                             
                                
                                
                                <td>$<span class="credit">'.$account["credit"].'</span></td>
                             
                                 
                              
                                
                             </tr>';
                          
                  
             

                      //  }
                       

                       

                        }
                           echo '<tr class="primary">
                                <td colspan="4">Total</td>
                             
                                <td>$<span class="font-weight-bold">'.$Debit.'</span></td>
                             
                                
                                
                                <td>$<span class="font-weight-bold">'. $Credit.'</span></td>
                             
                                 
                              
                                
                             </tr>';
                         }
                    }
       

}

                   
                    ?>
                    
               