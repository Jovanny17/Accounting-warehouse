<?php
function MakePaging($query,$page_size,$file)
	{
				
				$pagesize=$page_size;
				$get_total=$query;
				$prev="";
				$next="";
				$index="";
				$next_index="";
				$prev_index="";
				
				 
				$total_result=mysql_query($get_total);
				$numrows=mysql_num_rows($total_result);
				
				
				$total_pages=ceil($numrows/$pagesize);
				
				
		
				if(isset($_REQUEST['page']))	
					{
						
						$page=$_REQUEST['page'];
						if($page>$total_pages)
							{
								$page=1;
							}
						$start=($pagesize*$page)-$pagesize;
						
					}
				else
					{
						$page=1;
						$start=0;
					}
                  
				   
				$new_query=$get_total." limit $start,$pagesize";		
				
				$result=mysql_query($new_query) or die("Could not execute");
				
				
						
				
				if($total_pages>1)
					{
					
					if($page>1)
						{
					$prev_index=$page-1;
$prev='<a href="'.$_SERVER['PHP_SELF'].'?file='.$file.'&page='.$prev_index.'"><span><font size="2">Prev&nbsp;&nbsp;</font></span></a>';
						}
					
							$index=$prev.'<span align="center">';


						for($j=1;$j<=$total_pages;$j++)
							{
							if($page!=$j)
								{
							if($j%50==0)
								{
								$index=$index.'<a href="'.$_SERVER['PHP_SELF'].'?file='.$file.'&page='.$j.'"><span><font size="2">'.$j.'</font></span></a>';
$index.="&nbsp;&nbsp;";
								}
								else
									{
										
$index=$index.'<a href="'.$_SERVER['PHP_SELF'].'?file='.$file.'&page='.$j.'"><span><font size="2">'.$j.'</font></span></a>';
$index.="&nbsp;&nbsp;";
									
									}
					}
					else
						{
						
$index=$index.'<span><font size="2">'.$j.'</font></span>';
$index.="&nbsp;&nbsp;";
						}
							}
						
						if($page<$total_pages)
						{
					$next_index=$page+1;
					
$next='<a href="'.$_SERVER['PHP_SELF'].'?file='.$file.'&page='.$next_index.'"><span><font size="2">Next</font></span></a>';
						}	
						$index=$index.$next;
						$index=$index.'</span><br><br>';
						
					}		
					
				return ($index."***".$new_query."***".$total_pages);
				
				
	
	}
	



function UserPaging($query,$page_size,$file)
	{
				
				$pagesize=$page_size;
				$get_total=$query;
				$prev="";
				$next="";
				$index="";
				$next_index="";
				$prev_index="";
				
				 
				$total_result=mysql_query($get_total);
				$numrows=mysql_num_rows($total_result);
				
				
				$total_pages=ceil($numrows/$pagesize);
				
				
		
				if(isset($_REQUEST['page']))	
					{
						
						$page=$_REQUEST['page'];
						if($page>$total_pages)
							{
								$page=1;
							}
						$start=($pagesize*$page)-$pagesize;
						
					}
				else
					{
						$page=1;
						$start=0;
					}
                  
				   
				$new_query=$get_total." limit $start,$pagesize";		
				
				$result=mysql_query($new_query) or die("Could not execute");
				
				
		$index.='<div class="pagination pagination-centered"><ul>';				
				
				if($total_pages>1)
					{
					
					if($page>1)
						{
					$prev_index=$page-1;
$prev='<li><a href="'.$_SERVER['PHP_SELF'].'?file='.$file.'&page='.$prev_index.'"><span><font size="2">Prev&nbsp;&nbsp;</font></span></a></li>';
						}
					
							//$index.=$prev.'<span align="center">';


						for($j=1;$j<=$total_pages;$j++)
							{
							if($page!=$j)
								{
							if($j%50==0)
								{
								$index=$index.'<li><a href="'.$_SERVER['PHP_SELF'].'?file='.$file.'&page='.$j.'">'.$j.'</a></li>';
//$index.="&nbsp;&nbsp;";
								}
								else
									{
										
$index=$index.'<li><a href="'.$_SERVER['PHP_SELF'].'?file='.$file.'&page='.$j.'">'.$j.'</a></li>';
//$index.="&nbsp;&nbsp;";
									
									}
					}
					else
						{
						
$index=$index.'<li>'.$j.'</li>';
//$index.="&nbsp;&nbsp;";
						}
							}
						
						if($page<$total_pages)
						{
					$next_index=$page+1;
					
$next='<li><a href="'.$_SERVER['PHP_SELF'].'?file='.$file.'&page='.$next_index.'"><span><font size="2">Next</font></span></a>';
						}	
						//$index=$index.$next;
						//$index=$index.'</span><br><br>';
						
					}		
				$index.='</ul></div>';
				return ($index."***".$new_query."***".$total_pages);
	
	}
	

?>