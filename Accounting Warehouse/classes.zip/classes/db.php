<?php



	



//+----------------------------------------+



class DB  { // database class contains the function



	



	var $dbase;



	var $connection;



	var $dbServer;



	var $dbUser ;



	var $dbPass ;



	var $dbName ;



	var $dbmsg;



	var $dbquery;



	var $sitename;



	var $db_links;



	var $db_records;



	var $new_sql;



	



	



	function DB()



		{



					$this->dbServer = "localhost";



					$this->dbUser = "theazsjv_itsasif";



					$this->dbPass = "@#dikhan0070";



					$this->dbName = "theazsjv_accounting";



					$this->dbmsg="";



					$this->dbquery="";







					// $this->sitename="http://www.thewebprogrammers.com/base/";



		



		$this->connection = mysqli_connect($this->dbServer, $this->dbUser, $this->dbPass)



	    				or die("Could not connect : " . @mysqli_error());	    	    



	    



		$this->dbase = mysqli_select_db($this->connection,$this->dbName);



				



		



		if(!$this->connection || !$this->dbase)



				{			



						



			return false;



				}



		else{					







			return true;



			}



			



			echo $this-connection;



		}







		function __DB()



			{



				echo "Hello Asif";



			



			}	



//==============================	



	function selectMultiRecords($query)



	 {   



	 	//echo $query;



		//exit;



		if((@$result = mysqli_query($this->connection,$query))==FALSE)



		{



			if (DEBUG=="True")



			{



				echo mysqlMessage($query);



				mysqli_error($query);		



			}	



		}   



		else



		{	



			$count = 0;



			$data = array();



			



			while ( $row = mysqli_fetch_array($result)) 



			{



			



				 $data[$count] = $row;



				 $count++;



				//echo "<br>";



			}



				return $data;



		}



	}		







function Search_Record($table,$where,$order)



	 {   



	 	$this->dbquery="SELECT * FROM ".$table.$where;



		if((@$result = mysqli_query($this->connection,$query))==FALSE)



		{



			if (DEBUG=="True")



			{



				echo mysqlMessage($query);



				mysqli_error($query);		



			}	



		}   



		else



		{	



			$count = 0;



			$data = array();



			



			while ( $row = mysqli_fetch_array($result)) 



			{



			



				 $data[$count] = $row;



				 $count++;



				//echo "<br>";



			}



				return $data;



		}



	}		



	



function ExecuteQuery($query)



	 {   







		mysqli_query($this->connection,$query);



		return true;



	}		







//===============================



	function selectFrom($query)



	{



		



		if((@$result = mysqli_query($this->connection,$query))==FALSE) 



		{



			if (DEBUG=="True")



			{



				echo mysqlMessage($query);		



			}	



		}   



		else



		{	



			if ($check=mysqli_fetch_array($result))



			{



				return $check;



			}



				return false;	



		}



	}



//==========================



function countRecords($query)



	{	



		



		$res = mysqli_query($this->connection,$query);



		if (!$res) {



    die(mysqli_error($this->connection));



}



		$results = mysqli_num_rows($res);



//echo $results;



//exit;



		return $results;



	}		



			



//==============================	



function isExist($query) {	



	



	   if((@$result = mysqli_query($this->connection,$query))==FALSE){



			if (DEBUG == "True"){



				echo mysqlMessage($query);		



			}	



		} else { 



			if ($check=mysqli_fetch_array($result)){//mysqli_fetch_array return flase if there are no records



				return $check;



			}



		return false;	



		}//else 



	}



		function insertInto($query)



	{	//echo $Querry_Sql;



	   if((@$result = mysqli_query($query))==FALSE)



		{



			if (DEBUG=="True")



			{



				echo mysqlMessage($query);		



			}	



		}   



		else



		{	



			return true;	



		}



	}



	



	



	function deleteFrom($query)



	{



		if((@$result = mysqli_query($this->connection,$query))==FALSE)



		{



			if (DEBUG=="True")



			{



				echo mysqlMessage($query);		



			}	



		}   



		else



		{	



			return true;	



		}



	}







//================================



function update($query)



	{



		



		if((@$result = mysqli_query($this->connection,$query))==FALSE)



		{



			if (DEBUG=="True")



			{



			  echo mysqlMessage($query);		



			}	



		}   



		else



		{	



			return true;



		}



	}	



	function mysqlMessage($query)



	{



		echo "<div align='left'><strong><font color='red'>Site Name &nbsp;&nbsp;e	r r o r:</font></strong><br>";



		echo "Error in your Query: $query<BR>";



		echo "<strong><font color='red'>m y s q l &nbsp;g e n e r a t e d &nbsp;e r r o r:</font></strong><BR>";



		echo mysqli_errno() . " " . mysqli_error() . "</div>";



	}			



	



	



	function Add_Record($table,$fields,$vals)



		{	



				$this->dbquery="INSERT INTO ".$table."(".$fields.") VALUES(".$vals.")";



				//echo "INSERT INTO ".$table."(".$fields.") VALUES(".$vals.")<br>";



				///exit;



			if(mysqli_query($this->connection,$this->dbquery))



				{



					return true;



				



				}



			else



				{



					return false;



				



				}



				



		



		}



		



	



	function Update_Record($table,$params)



		{	



				$this->dbquery="UPDATE ".$table." SET ".$params;



				//==echo "UPDATE ".$table." SET ".$params;



				//exit;



			if(mysqli_query($this->connection,$this->dbquery))



				{



					return true;



				



				}



			else



				{



					return false;



				



				}



				



		



		}







	function Update_Record_join($table,$join,$params)



		{	



				$this->dbquery="UPDATE ".$table.$join." SET ".$params;



				// echo "UPDATE ".$table.$join." SET ".$params;



				// exit;



			if(mysqli_query($this->connection,$this->dbquery))



				{



					return true;



				



				}



			else



				{



					return false;



				



				}



				



		



		}



	



	function Delete_Record($table,$params)



		{



		



				



				$this->dbquery="DELETE FROM ".$table." WHERE ".$params;



				



				//echo "DELETE FROM ".$table." WHERE ".$params;



				



				//exit;



			



			if(mysqli_query($this->connection,$this->dbquery))



				{



					return true;



				



				}



			else



				{



					return false;



				



				}



				



		



		}



		



		



function paging($query,$page_size,$file)



	{



				



				//echo $query;



				$file=basename($_SERVER['PHP_SELF']).'?'.$_SERVER['QUERY_STRING'];



				$file = preg_replace("/&page=[0-9]/","",$file);



				$pagesize=$page_size;



				$get_total=$query;



				$prev="";



				$next="";



				$index="";



				$next_index="";



				$prev_index="";



				



				 



				$total_result=mysqli_query($get_total);



				$numrows=mysqli_num_rows($total_result);



				



				



				$total_pages=ceil($numrows/$pagesize);



				



				



		



				if(isset($_REQUEST['page']))	



					{



						



						$page=$_REQUEST['page'];



						if($page>$total_pages)



							{



								$page=1;



							}



						$start=($pagesize*$page)-$pagesize;



						



					}



				else



					{



						$page=1;



						$start=0;



					}



                  



				   



				$new_query=$get_total." limit $start,$pagesize";		



				



				$result=mysqli_query($new_query) or die("Could not execute");



				



				



						



				



				if($total_pages>1)



					{



					



					if($page>1)



						{



					$prev_index=$page-1;



$prev='<a href="'.$file.'&page='.$prev_index.'"><span><font size="2">Prev&nbsp;&nbsp;</font></span></a>';



						}



					



							$index=$prev.'<span align="center">';











						for($j=1;$j<=$total_pages;$j++)



							{



							if($page!=$j)



								{



							if($j%50==0)



								{



								$index=$index.'<a href="'.$file.'&page='.$j.'"><span><font size="2">'.$j.'</font></span></a>';



$index.="&nbsp;&nbsp;";



								}



								else



									{



										



$index=$index.'<a href="'.$file.'&page='.$j.'"><span><font size="2">'.$j.'</font></span></a>';



$index.="&nbsp;&nbsp;";



									



									}



					}



					else



						{



						



$index=$index.'<span><font size="2">'.$j.'</font></span>';



$index.="&nbsp;&nbsp;";



						}



							}



						



						if($page<$total_pages)



						{



					$next_index=$page+1;



					



$next='<a href="'.$file.'&page='.$next_index.'"><span><font size="2">Next</font></span></a>';



						}	



						$index=$index.$next;



						$index=$index.'</span><br><br>';



						



					}		



					//echo "<h1>%".$index."%<h1>";



				$this->db_links=$index;



				$this->db_records=$numrows;



				$this->new_sql=$new_query;



				return ($index."***".$new_query."***".$numrows);



	



	}



function Close_Connection()



	{



		mysqli_close($this->connection);



	



	}

function getPage($url) {

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_USERAGENT, 'Googlebot/2.1 (+http://www.google.com/bot.html)');
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_FAILONERROR, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($curl, CURLOPT_TIMEOUT, 50);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
      	
	    $html = curl_exec($curl);
		curl_close($curl);
		return $html;
      
      
 }











}//========end of class	











?>