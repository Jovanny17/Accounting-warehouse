<?php
class Functions
{


	
	function Redirect($url)
	{
		echo "<script>window.location.href='".$url."'</script>";
		exit;
	}
	
    function Add_Log($module,$user_id,$notification)	{
			global $db;
			
			$db->Add_Record("logs","module,user_id,notification","'$module','$user_id','$notification'");
		
		
	}
	

	function ShowMessage($msg)
		{
			echo "<script>alert('".$msg."');</script>";
		
		
		}

	function PrettyArray($arr)
		{
			return "<pre>".$arr."</pre>";
		
		
		}
  	function SignUp_Notify($emails,$account_info) {
		global $mail;
		
		
				$body='';
				
				$body.='<table width="70%" align="center"  border="0" cellpadding="5" style="border:0px solid #E8E8E8">';
				$body.='<tr>';
				$body.='<th ><h1>New User Registration</h1></th>';
				$body.='</tr>';
				$body.='</table>';
				
				$body.='<table width="70%" align="center" class="tableshow" border="0" cellpadding="5" style="border:1px solid #E8E8E8">';
				$body.='<tr>';
				$body.='<td class="Heading" colspan="2">Member Information</td>';
				$body.='</tr>';
				$body.='<tr>';
				$body.='<td ><strong>First Name</strong></td><td>'.$account_info["firstname"]."</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>Last Name</strong></td><td>'.$account_info["lastname"]."</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>Email Address</strong></td><td>'.$account_info["email"]."</td>";
				$body.='</tr>';
				
				
				$body.='<tr>';
				$body.='<td><strong>Company Name</strong></td><td>'.$account_info["companyname"]."</td>";
				$body.='</tr>';
				
				
				$body.='<tr>';
				$body.='<td><strong>Join Date</strong></td><td>'.date("d M Y H:i:s",strtotime($account_info["join_date"]))."</td>";
				$body.='</tr>';
				
				
				$body.='<tr>';
				$body.='<td>&nbsp;</td>';
					$body.='<td>&nbsp;</td>';
				$body.='</tr>';
				
				
				$body.='<tr>';
				$body.='<td>Please login to see more details</td>';
				$body.='</tr>';
				
				$body.='</table>';
				
				$body.='<br><table width="70%" align="center" class="tableshow" border="0" cellpadding="5" style="border:0px solid #E8E8E8">';
				$body.='<tr>';
				$body.='<th  align="left" >From,</th>';
				$body.='</tr>';
				$body.='<tr>';
				$body.='<th align="left" >Storm Assist Team</th>';
				$body.='</tr>';
				$body.='</table><br><br>';
				
				$body.='<style>
			.Heading {font-weight:bold; font-size:16px; background-color:rgb(235,235,235) ; text-align:left;border-bottom:1px solid #CCCCCC; font-family:Arial, 
			Helvetica, sans-serif}
			h1 {font-weight:bold;  text-align:left; font-family:Arial, 	Helvetica, sans-serif}
							.tableshow { border:1px solid #CCCCCC;font-family:Arial, Helvetica, sans-serif;font-size:12px}
							td {font-family:Arial, Helvetica, sans-serif;font-size:12px;border-bottom:1px solid #e8e8e8}
						</style>';
					
				$rec_array=explode(";",$emails);
				for($i=0;$i<count($rec_array);$i++) {
				
				$mail->IsMail();
				$mail->AddAddress($rec_array[$i]);
				$mail->Subject = "New User Signup";
				$mail->MsgHTML($body);
				$mail->IsHTML(true); 
				$mail->FromName="Storm Assist";
				$mail->Send();
				
		}

	
		
	}
	
	function Verification_Code($email,$securekey) {
		$verification_code="";
		
		$verification_code=md5(time().$email.$config['secure_key']);
		$verification_code=crypt($verification_code,$config['secure_key']);
		$notallowed = array("$", "/", ".","&");
		$verification_code=str_replace($notallowed,"",$verification_code);
		
		return $verification_code;
	}
	
	
	
	function ForgotPassword($config,$account_info) {
		global $mail;
		
		
				$body='';
				
				$body.='<table width="70%" align="center"  border="0" cellpadding="5" style="border:0px solid #E8E8E8">';
				$body.='<tr>';
				$body.='<th ><img src="'.$config["sitename"].'img/logo.png"><h1>Forgot Your Password</h1></th>';
				$body.='</tr>';
				$body.='</table>';
				
				$body.='<div>Please click on this link to verify your account</div><br><br>';
				$link=$config["sitename"]."ChangePassword.php?email=".$account_info['email']."&code=".$account_info["verification_code"];
				$body.="<div>If the button doesn't work, copy & paste this link into your browser.</div><br>";
				$body.='<div><a href="'.$link.'">'.$link.'</a></div>';
				$body.='<br><br><br>';
				$body.='<div>Thank You</div>';
								
				$body.='<br><table width="70%" align="center" class="tableshow" border="0" cellpadding="5" style="border:0px solid #E8E8E8">';
				$body.='<tr>';
				$body.='<th  align="left" >From,</th>';
				$body.='</tr>';
				$body.='<tr>';
				$body.='<th align="left" >Storm Assist Team</th>';
				$body.='</tr>';
				$body.='</table><br><br>';
				
				$body.='<style>
			.Heading {font-weight:bold; font-size:16px; background-color:rgb(235,235,235) ; text-align:left;border-bottom:1px solid #CCCCCC; font-family:Arial, 
			Helvetica, sans-serif}
			h1 {font-weight:bold;  text-align:left; font-family:Arial, 	Helvetica, sans-serif}
							.tableshow { border:1px solid #CCCCCC;font-family:Arial, Helvetica, sans-serif;font-size:12px}
							td {font-family:Arial, Helvetica, sans-serif;font-size:12px;border-bottom:1px solid #e8e8e8}
						</style>';
					
				$mail->IsMail();
				$mail->AddAddress($account_info["email"]);
				$mail->Subject = "Forgot Your Password - Storm Assist";
				$mail->MsgHTML($body);
				$mail->IsHTML(true); 
				$mail->FromName="Storm Assist";
				$mail->Send();
				
		
	}
	
	
	function WelcomeEmail($config,$account_info) {
		global $mail;
		
		
				$body='';
				
				$body.='<table width="70%" align="center"  border="0" cellpadding="5" style="border:0px solid #E8E8E8">';
				$body.='<tr>';
				$body.='<th ><img src="'.$config["sitename"].'img/logo.png"><h1>Welcome to Storm Assist</h1></th>';
				$body.='</tr>';
				$body.='</table>';
				
				$body.='<div>Please click on this link to verify your account</div><br><br>';
				$link=$config["sitename"]."VerifyAccount.php?email=".$account_info['email']."&code=".$account_info["verification_code"];
				$body.="<div>If the button doesn't work, copy & paste this link into your browser.</div><br>";
				$body.='<div><a href="'.$link.'">'.$link.'</a></div>';
				$body.='<br><br><br>';
				$body.='<div>Thank You</div>';
								
				$body.='<br><table width="70%" align="center" class="tableshow" border="0" cellpadding="5" style="border:0px solid #E8E8E8">';
				$body.='<tr>';
				$body.='<th  align="left" >From,</th>';
				$body.='</tr>';
				$body.='<tr>';
				$body.='<th align="left" >Storm Assist Team</th>';
				$body.='</tr>';
				$body.='</table><br><br>';
				
				$body.='<style>
			.Heading {font-weight:bold; font-size:16px; background-color:rgb(235,235,235) ; text-align:left;border-bottom:1px solid #CCCCCC; font-family:Arial, 
			Helvetica, sans-serif}
			h1 {font-weight:bold;  text-align:left; font-family:Arial, 	Helvetica, sans-serif}
							.tableshow { border:1px solid #CCCCCC;font-family:Arial, Helvetica, sans-serif;font-size:12px}
							td {font-family:Arial, Helvetica, sans-serif;font-size:12px;border-bottom:1px solid #e8e8e8}
						</style>';
					
				
				$mail->IsMail();
				$mail->AddAddress($account_info["email"]);
				$mail->Subject = "Welcome to Storm Assist";
				$mail->MsgHTML($body);
				$mail->IsHTML(true); 
				$mail->FromName="Storm Assist";
				$mail->Send();
				
		
	}
	
	
	
	
	function MemberClaimEmail($email,$claim_info) {
		global $mail;
		
		
				$body='';
				
				$body.='<table width="70%" align="center"  border="0" cellpadding="5" style="border:0px solid #E8E8E8">';
				$body.='<tr>';
				$body.='<th ><h1>Your Claim</h1></th>';
				$body.='</tr>';
				$body.='</table>';
				
				$body.='<p>Your Claim has been Successfully added . You can now enter other details and upload Documents';
				
				
				$body.='<br><table width="70%" align="center" class="tableshow" border="0" cellpadding="5" style="border:0px solid #E8E8E8">';
				$body.='<tr>';
				$body.='<th  align="left" >From,</th>';
				$body.='</tr>';
				$body.='<tr>';
				$body.='<th align="left" >Storm Assist Team</th>';
				$body.='</tr>';
				$body.='</table><br><br>';
				
				$body.='<style>
			.Heading {font-weight:bold; font-size:16px; background-color:rgb(235,235,235) ; text-align:left;border-bottom:1px solid #CCCCCC; font-family:Arial, 
			Helvetica, sans-serif}
			h1 {font-weight:bold;  text-align:left; font-family:Arial, 	Helvetica, sans-serif}
							.tableshow { border:1px solid #CCCCCC;font-family:Arial, Helvetica, sans-serif;font-size:12px}
							td {font-family:Arial, Helvetica, sans-serif;font-size:12px;border-bottom:1px solid #e8e8e8}
						</style>';

					
				
				
				$mail->IsMail();
				$mail->AddAddress($email);
				$mail->Subject = "Your Claim";
				$mail->MsgHTML($body);
				$mail->IsHTML(true); 
				$mail->FromName="Storm Assist";
				$mail->Send();
				
	

	
		
	}
	
	
	
	function NewClaim_Notify($emails,$claim_info) {
		global $mail;
		
		
				$body='';
				
				$body.='<table width="70%" align="center"  border="0" cellpadding="5" style="border:0px solid #E8E8E8">';
				$body.='<tr>';
				$body.='<th ><h1>New Claim Added</h1></th>';
				$body.='</tr>';
				$body.='</table>';
				
				$body.='<table width="70%" align="center" class="tableshow" border="0" cellpadding="5" style="border:1px solid #E8E8E8">';
				$body.='<tr>';
				$body.='<td class="Heading" colspan="2">Claim Information</td>';
				$body.='</tr>';
				$body.='<tr>';
				$body.='<td ><strong>Claim Added By</strong></td><td>'.$claim_info["lastname"].' '.$claim_info["firstname"].' ('.$claim_info["email"].")</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>Date of Loss</strong></td><td>'.$claim_info["claim_date"]."</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>Insured`s Name</strong></td><td>'.$claim_info["customer_name"]."</td>";
				$body.='</tr>';
				
				
				$body.='<tr>';
				$body.='<td><strong>Insured`s Number</strong></td><td>'.$claim_info["customer_number"]."</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>Address</strong></td><td>'.$claim_info["address"]."</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>City/Town</strong></td><td>'.$claim_info["city"]."</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>State/Province/Region</strong></td><td>'.$claim_info["state"]."</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>Postal Code</strong></td><td>'.$claim_info["zip"]."</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>Country</strong></td><td>'.$claim_info["country"]."</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>Technician Service Name</strong></td><td>'.$claim_info["service_name"]."</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>Claim Type</strong></td><td>'.$claim_info["claim_type"]."</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>Type</strong></td><td>'.$claim_info["claim_area"]."</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>Rush</strong></td><td>'.$claim_info["rush"]."</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>Sketch</strong></td><td>'.$claim_info["sketch"]."</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>Process</strong></td><td>'.$claim_info["process"]."</td>";
				$body.='</tr>';
				
				$body.='<tr>';
				$body.='<td><strong>Message</strong></td><td>'.$claim_info["message"]."</td>";
				$body.='</tr>';
				
							
				$body.='<tr>';
				$body.='<td><strong>Added Date</strong></td><td>'.date("d M Y H:i:s",strtotime($claim_info["added_date"]))."</td>";
				$body.='</tr>';
				
				
				$body.='<tr>';
				$body.='<td>&nbsp;</td>';
					$body.='<td>&nbsp;</td>';
				$body.='</tr>';
				
				
				$body.='<tr>';
				$body.='<td>Please login to see more details</td>';
				$body.='</tr>';
				
				$body.='</table>';
				
				$body.='<br><table width="70%" align="center" class="tableshow" border="0" cellpadding="5" style="border:0px solid #E8E8E8">';
				$body.='<tr>';
				$body.='<th  align="left" >From,</th>';
				$body.='</tr>';
				$body.='<tr>';
				$body.='<th align="left" >Storm Assist Team</th>';
				$body.='</tr>';
				$body.='</table><br><br>';
				
				$body.='<style>
			.Heading {font-weight:bold; font-size:16px; background-color:rgb(235,235,235) ; text-align:left;border-bottom:1px solid #CCCCCC; font-family:Arial, 
			Helvetica, sans-serif}
			h1 {font-weight:bold;  text-align:left; font-family:Arial, 	Helvetica, sans-serif}
							.tableshow { border:1px solid #CCCCCC;font-family:Arial, Helvetica, sans-serif;font-size:12px}
							td {font-family:Arial, Helvetica, sans-serif;font-size:12px;border-bottom:1px solid #e8e8e8}
						</style>';
					
				$rec_array=explode(";",$emails);
				for($i=0;$i<count($rec_array);$i++) {
				
				$mail->IsMail();
				$mail->AddAddress($rec_array[$i]);
				$mail->Subject = "New Claim Added";
				$mail->MsgHTML($body);
				$mail->IsHTML(true); 
				$mail->FromName="Storm Assist";
				$mail->Send();
				
		}

	
		
	}
	
	
	function ValidImage($inputname,$inputtype,$tmp_name,$extension) {
			 $whitelist = array(".jpg",".jpeg",".gif",".png"); 
			 $inputname = strtolower($inputname);
			 $inputtype = strtolower($inputtype);
			
			 $pos = strpos($drawingname,'php');
			 if(!($pos === false)) {
				  return false;
			 }

 			$input_ext = strrchr($inputname, '.');
			
			 if (!(in_array($input_ext, $whitelist))) {
				   return false;
 			}
			
			 if (!(in_array(".".$extension, $whitelist))) {
			 		   return false;
 			}
			
			$pos = strpos($inputtype,'image');
 				if($pos === false) {
					  return false;
 					}
			$imageinfo = getimagesize($tmp_name);
			
			if($imageinfo['mime'] != 'image/gif' && 
									$imageinfo['mime'] != 'image/jpeg'&& $imageinfo['mime']  
									    != 'image/jpg'&& $imageinfo['mime'] != 'image/png') {
				  return false;
 				}

			if(substr_count($inputtype, '/')>1){
				 return false;
				}

			return true;
	
	}
	
	
	function ValidDocument($inputname,$inputtype,$tmp_name,$extension) {
			 $whitelist = array(".jpg",".jpeg",".gif",".doc",".docx",".xls",".xlsx",".ppt",".pptx",".pdf",".txt",".csv"); 
			 $inputname = strtolower($inputname);
			 $inputtype = strtolower($inputtype);
			
			 $pos = strpos($drawingname,'php');
			 if(!($pos === false)) {
				  return false;
			 }

 			$input_ext = strrchr($inputname, '.');
			
			 if (!(in_array($input_ext, $whitelist))) {
				   return false;
 			}
			
			 if (!(in_array(".".$extension, $whitelist))) {
			 		   return false;
 			}
			
			if(substr_count($inputtype, '/x-php')>1){
				 return false;
				}

			return true;
	
	}
	
	
	function create_thumb($src_image, $dest_image, $width,$height, $jpg_quality = 90) {
 
    // Get dimensions of existing image
    $image = getimagesize($src_image);
 
    // Check for valid dimensions
    if( $image[0] <= 0 || $image[1] <= 0 ) return false;
 
    // Determine format from MIME-Type
    $image['format'] = strtolower(preg_replace('/^.*?\//', '', $image['mime']));
 
    // Import image
    switch( $image['format'] ) {
        case 'jpg':
        case 'jpeg':
            $image_data = imagecreatefromjpeg($src_image);
        break;
        case 'png':
            $image_data = imagecreatefrompng($src_image);
        break;
        case 'gif':
            $image_data = imagecreatefromgif($src_image);
        break;
        default:
            // Unsupported format
            return false;
        break;
    }
 
    // Verify import
    if( $image_data == false ) return false;
 
    // Calculate measurements
    if( $image[0] > $image[1] ) {
        // For landscape images
        $x_offset = ($image[0] - $image[1]) / 2;
        $y_offset = 0;
        $square_size = $image[0] - ($x_offset * 2);
    } else {
        // For portrait and square images
        $x_offset = 0;
        $y_offset = ($image[1] - $image[0]) / 2;
        $square_size = $image[1] - ($y_offset * 2);
    }
 
    // Resize and crop
    $canvas = imagecreatetruecolor($width, $height);
    if( imagecopyresampled(
        $canvas,
        $image_data,
        0,
        0,
        $x_offset,
        $y_offset,
        $width,
        $height,
        $square_size,
        $square_size
    )) {
 
        // Create thumbnail
        switch( strtolower(preg_replace('/^.*\./', '', $dest_image)) ) {
            case 'jpg':
            case 'jpeg':
                return imagejpeg($canvas, $dest_image, $jpg_quality);
            break;
            case 'png':
                return imagepng($canvas, $dest_image);
            break;
            case 'gif':
                return imagegif($canvas, $dest_image);
            break;
            default:
                // Unsupported format
                return false;
            break;
        }
 
    } else {
        return false;
    }
 
}


function save_image($inPath,$outPath)
{ //Download images from remote server
		
	$inPath=str_replace("https://","http://",$inPath);
    $in=    fopen($inPath, "rb");
    $out=   fopen($outPath, "wb");
    while ($chunk = fread($in,8192))
    {
        fwrite($out, $chunk, 8192);
    }
    fclose($in);
    fclose($out);
}

function copyImage($srcFile, $destFile, $w, $h, $quality = 75)
{
    $tmpSrc     = pathinfo(strtolower($srcFile));
    $tmpDest    = pathinfo(strtolower($destFile));
    $size       = getimagesize($srcFile);

	
    if ($tmpDest['extension'] == "jpg")
    {
       $destFile  = substr_replace($destFile, 'jpg', -3);
       $dest      = imagecreatetruecolor($w, $h);
       imageantialias($dest, TRUE);
    } elseif ($tmpDest['extension'] == "png") {
       $dest = imagecreatetruecolor($w, $h);
       imageantialias($dest, TRUE);
   	} elseif ($tmpDest['extension'] == "gif") {
      $destFile  = substr_replace($destFile, 'gif', -3);
       $dest      = imagecreatetruecolor($w, $h);
       imageantialias($dest, TRUE);
    } else {
      return false;
    }

    switch($size[2])
    {
       case 1:       //GIF
           $src = imagecreatefromgif($srcFile);
           break;
       case 2:       //JPEG
           $src = imagecreatefromjpeg($srcFile);
           break;
       case 3:       //PNG
           $src = imagecreatefrompng($srcFile);
           break;
       default:
           return false;
           break;
    }

    imagecopyresampled($dest, $src, 0, 0, 0, 0, $w, $h, $size[0], $size[1]);

    switch($size[2])
    {
       case 1:
       case 2:
           imagejpeg($dest,$destFile, $quality);
           break;
       case 3:
           imagepng($dest,$destFile);
    }
    return $destFile;

}
 function array_values_recursive($array){
                  $temp = array();

                 foreach ($array as $value) {
                         if(is_array($value)) { $temp[] = $this->array_values_recursive($value); }
                         else { $temp[] = $value; }
                 }
                 return $temp;
            }
	
	function friendly_seo_string($vp_string){
    
    $vp_string = trim($vp_string);
    
    $vp_string = html_entity_decode($vp_string);
    
    $vp_string = strip_tags($vp_string);
    
    $vp_string = strtolower($vp_string);
    
    $vp_string = preg_replace('~[^ a-z0-9_.]~', ' ', $vp_string);
    
    $vp_string = preg_replace('~ ~', '-', $vp_string);
    
    $vp_string = preg_replace('~-+~', '-', $vp_string);
        
    return $vp_string;
    } 	

  }// end of class
?>