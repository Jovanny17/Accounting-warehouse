<?php

//========================================

class Categories extends DB

{ 

	var $record_num;
	var $page_links;
	var $page_arr;

	function GetCategoryById($category_id)

	{

				$query="SELECT * FROM categories  WHERE file_id=".$category_id;	
				return $this->selectFrom($query);	

	}

	function AllCategories($where,$page_size,$page)

	{

		$query="select * from categories ".$where."  order by category_id desc";


			$this->paging($query,$page_size,$page);

			$this->record_num=$this->db_records;

			$this->page_links='<div>'.$this->db_links."</div>";

			$this->db_links='';

			return $this->selectMultiRecords($this->new_sql);

	

	}




}			

?>

