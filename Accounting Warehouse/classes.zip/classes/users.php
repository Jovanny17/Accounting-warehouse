<?php
//========================================
class Users extends DB
{ 

	var $record_num;
	var $page_links;
	var $page_arr;
	
	
	function Get_User($user_id)
	{
				$query="SELECT * FROM users WHERE user_id=".$user_id;	
				return $this->selectFrom($query);	
	}
	function GetUserByEmail($email)
	{
				$query="SELECT * FROM users WHERE email=".$email;	
				return $this->selectFrom($query);	
	}
	
	function Check_Email($email)
		{
				$query="select email from users where email='".$email."'";
				return $this->countRecords($query);	
				
		}
		

	function Get_UserByEmail($email)
		{
			$query="SELECT * FROM users WHERE email='".$email."'";	
			return $this->selectFrom($query);	
		
		
		}
	
	

function Get_AllUsers($where,$page_size,$page)
	{
		$query="select * from users	";
		$query.=$where;
		$query.=" order by user_id desc";
		
		
			$this->paging($query,$page_size,$page);
			$this->record_num=$this->db_records;
			$this->page_links='<div>'.$this->db_links."</div>";
			$this->db_links='';
			return $this->selectMultiRecords($this->new_sql);
	
	}


}			
?>
