<?php 
    
// Function to get all feed of a page with like, comment and share count.
function feedExtract($url="",$pageFBID) // $url contain url for next pages and $page contain page id
{
    global $token, $connection;  // database connection and tocken required
    
    // first time fetch page posts
    $response = file_get_contents_curl("https://graph.facebook.com/v2.6/$pageFBID/feed?fields=picture,message,story,created_time,shares,likes.limit(1).summary(true),comments.limit(1).summary(true)&access_token=".$token);
    
    $query = "SELECT id FROM pages where pageID='".$pageFBID."'"; // select feed already in database or not query.
    $result = mysqli_query($connection,$query);            // execute query
    $fieldID = mysqli_fetch_row($result);
    $pageID  = $fieldID['0'];
    // decode json data to array
    $get_data = json_decode($response,true);
    // loop extract data
    for($ic=0;$ic<count($get_data['data']);$ic++)
    {
        // Exracting Day, Month, Year
        $date = date_create($get_data['data'][$ic]['created_time']);
        $newDate = date_format($date,'Y-m-d H:i:s');
        
        
        // $story of post in if link, video or image it will return "message" plain status as "story"
        $story = $get_data['data'][$ic]['message'];
        
        if(!isset($story))
            $story = $get_data['data'][$ic]['story'];
        
        
        $query = "SELECT id FROM feed where PostID='".$get_data['data'][$ic]['id']."'"; // select page id from pages table.
        $result = mysqli_query($connection,$query);            // execute query
        $numResults = mysqli_num_rows($result);               // number of records
        if($numResults>=1)                        // if post found in database then run update query
        {
            //Update Record
            mysqli_query($connection,"update `feed`  set 
            `Comments` = '".mysqli_real_escape_string($connection,$get_data['data'][$ic]['comments']['summary']['total_count'])."' ,  
            `Likes`  = '".mysqli_real_escape_string($connection,$get_data['data'][$ic]['likes']['summary']['total_count'])."',  
            `Shares`  = '".mysqli_real_escape_string($connection,$get_data['data'][$ic]['shares']['count'])."' 
            where `PostID` = '".mysqli_real_escape_string($connection,$get_data['data'][$ic]['id'])."'");
        }
        else
        {
        
            // Puting data in sql query values
            $dataFeed = "(
            '".mysqli_real_escape_string($connection,$pageID)."', 
            '".mysqli_real_escape_string($connection,$newDate)."',
            '".mysqli_real_escape_string($connection,$story)."',
            '".mysqli_real_escape_string($connection,$get_data['data'][$ic]['picture'])."',
            '".mysqli_real_escape_string($connection,$get_data['data'][$ic]['comments']['summary']['total_count'])."',
            '".mysqli_real_escape_string($connection,$get_data['data'][$ic]['likes']['summary']['total_count'])."',
            '".mysqli_real_escape_string($connection,$get_data['data'][$ic]['shares']['count'])."',
            '".mysqli_real_escape_string($connection,$get_data['data'][$ic]['id'])."')";
            
            mysqli_query($connection,"INSERT INTO  `feed` (`PageID` ,  `Date` ,  `Post` ,  `Picture` ,  `Comments` ,  `Likes` ,  `Shares` ,  `PostID` ) VALUES $dataFeed");
        }
    }
    
    // Return message.
    return  1;
}

function getFacebookId($pageID) // This function return facebook page details by its url
{
    // get token from main file
    global $token;   

    $json = file_get_contents_curl('https://graph.facebook.com/'.$pageID.'?fields=talking_about_count,name&access_token='.$token); 
    // decode returned json data in arrau.
    $json = json_decode($json);
    return $json;
}

// file get content with curl method 
function file_get_contents_curl($url)
{
    $curl = curl_init($url);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
  $data = curl_exec($curl);
  curl_close($curl);
  return $data;
}
?>