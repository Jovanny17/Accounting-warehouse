<?php

require_once('./config.php');
require_once("./check_session.php");
$profile_info=$db->selectFrom("select * from users where user_id=".$_SESSION['user_id']);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>ACCOUNTING WAREHOUSE</title>

<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>

<!-- Bootstrap 3.3.4 -->

<link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />

<!-- FontAwesome 4.3.0 -->

<link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<!-- Ionicons 2.0.0 -->

<link href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet" type="text/css" />

<!-- Theme style -->

<link href="assets/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />

<!-- Datatables style -->

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.16/af-2.2.2/b-1.5.1/b-colvis-1.5.1/b-flash-1.5.1/b-html5-1.5.1/b-print-1.5.1/cr-1.4.1/fc-3.2.4/fh-3.1.3/kt-2.3.2/r-2.2.1/rg-1.0.2/rr-1.2.3/sc-1.4.4/sl-1.2.5/datatables.min.css"



  />


<link href="assets/dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />


<style>




    .error {



      color: red;



      font-weight: normal;



    }
    

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #2A3740;
  min-width: 160px;
  width:230px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 1;
}
.dropdown:hover .dropdown-content {
  display: block;
  width:230px;
}
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
.dropdown-content a:hover {
    background-color: #585858;

    
}

  </style>

<!-- jQuery 2.1.4 -->

<script src="assets/js/jQuery-2.1.4.min.js"></script>

<script type="text/javascript">



    var baseURL = "http://localhost/task2/manager/";



  </script>

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

<!--[if lt IE 9]>



        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>



        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>



    <![endif]-->

</head>

<body class="skin-red sidebar-mini">

<div class="wrapper">

<header class="main-header">

  <!-- Logo -->



  <!-- mini logo for sidebar mini 50x50 pixels -->


  

  <nav class="navbar navbar-static-top" role="navigation">

    <!-- Sidebar toggle button-->

    <a href="#" class="sidebar-toggle" data-toggle="offcanvas" id="sidebar_button" role="button"> <span class="sr-only">Toggle navigation</span> </a>

    <div class="navbar-custom-menu">

      <ul class="nav navbar-nav">
      
        <li class="dropdown tasks-menu"><a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true"> <i class="fa fa-history"></i> </a>

          <ul class="dropdown-menu">

            <li class="header"> Last Login : <i class="fa fa-clock-o"></i> <?php echo $_SESSION['last_login']; ?> </li>

          </ul>

        </li>

        <!-- User Account: style can be found in dropdown.less -->

       <li class="dropdown user user-menu"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">
        <?php if($profile_info['profile_image'] !="" && file_exists("uploads/".$profile_info['profile_image'])) { ?>
                
                <img src="thumb.php?src=uploads/<?php echo $profile_info['profile_image']; ?>&size=50x50" class="user-image" alt="User Image" />
          
         <?php } else { ?>
                <img src="assets/dist/img/avatar.png" class="user-image" alt="User Image" />
         <?php } ?>
          <span class="hidden-xs"><?php echo $profile_info['name']; ?> </span> </a>

          <ul class="dropdown-menu">

            <!-- User image -->

            <li class="user-header"> 
            <?php if($profile_info['profile_image'] !="" && file_exists("uploads/".$profile_info['profile_image'])) { ?>
                       
                        <img src="thumb.php?src=uploads/<?php echo $profile_info['profile_image']; ?>&size=150x150" class="img-circle" alt="User Image" />
            <?php } else { ?>
                        <img src="assets/dist/img/avatar.png" class="img-circle" alt="User Image" />
            <?php } ?>

                <p><?php echo $profile_info['first_name']; ?></p> 

                <?php   if($_SESSION['group_id']=='1') { ?>

                <small> Admin </small>

                <?php } ?>

                <?php   if($_SESSION['group_id']=='2') { ?>

                <small> Manager </small>

                <?php } ?>

                <?php   if($_SESSION['group_id']=='4') { ?>

                <small> Accountant </small>

                <?php } ?>

            </li>

            <!-- Menu Footer-->

            <li class="user-footer">

              <div class="pull-left"> <a href="profile.php" class="btn btn-default btn-flat"> <i class="fa fa-key"></i> Account settings </a> </div>

              <div class="pull-right"> <a href="./logout.php" class="btn btn-default btn-flat"> <i class="fa fa-sign-out"></i> Log out</a> </div>

            </li>

          </ul>

        </li>

      </ul>

    </div>

  </nav>

</header>

<aside class="main-sidebar">

  <!-- sidebar: style can be found in sidebar.less -->

  <section class="sidebar">

    <!-- sidebar menu: : style can be found in sidebar.less -->

    <ul class="sidebar-menu">
        
      <div style="background-color:#C5D3D9;margin-top:-50px; height:240px;"> <ul class="sidebar-menu"><span style="margin-left:-10px;"class="logo-lg"><b><img style="margin-top:20px;" src="images/AW_Logo.png" width="250" height="250" /></b></span></div>

      <li class="header"> </li>

      <li class="treeview"> <a href="index.php"> <i class="fa fa-dashboard"></i> <span>Home</span> </i> </a> </li>


    <div class="dropdown">
    <li class="treeview" style="margin-left:30.5%; padding:5.5%;color:#C5D3D9;"><i class="fa fa-file"></i><span>Reports</span></i></a></li>
    <div class="dropdown-content">
        <a href="trialbalance.php" style="color:white;">Trial Balance</a>
        <a href="balancesheet2.php" style="color:white;">Balance Sheet</a>
        <a href="incomestatement.php" style="color:white;">Income Statement</a>
    </div>
    </div>
    
	 
    
		
		<li class="treeview"> <a href="chart_accounts.php"> <i class="fa fa-bar-chart"></i> <span>Chart of Accounts</span> </a> </li>
		
		
		
   		 <li class="treeview"> <a href="send.php"> <i class="fa fa-mail-reply"></i> <span>Email</span> </a> </li>
		
		<?php if($_SESSION['group_id']=="2" || $_SESSION['group_id']=="4"){?>
		 
     <div class="dropdown">
    <li class="treeview" style="margin-left:30.5%; padding:5.5%;color:#C5D3D9;"><i class="fa fa-newspaper-o"></i>  <span>Journals</span> </li>
    <div class="dropdown-content">
    <a href="journal.php" style="color:white;">All  Journals</a>
        <a href="approved_journal.php" style="color:white;">Approved  Journals</a>
        <a href="pending_journal.php" style="color:white;">Pending Journals</a>
        <a href="rejected_journal.php" style="color:white;">Rejected Journals</a>
    </div>
    </div>
		 <?php }?>
		 
		 
		<?php if($_SESSION['group_id']=="1"){ ?>
			<li class="treeview"> <a href="users.php"> <i class="fa fa-users"></i> <span>Employees</span> </a> </li>    
		<?php } ?>
		
		<?php if($_SESSION['group_id']=="1"){?>
		 <li class="treeview"> <a href="expired_users.php"> <i class="fa fa-key"></i> <span>Expired Passwords</span> </a> </li>
		 <?php }?>
		
     

    </ul>

  </section>

  <!-- /.sidebar -->

</aside>

